export interface auth {

  email: string;
  type: string;

}
