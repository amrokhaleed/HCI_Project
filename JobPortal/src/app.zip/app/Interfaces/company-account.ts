export interface company_account {
  name?: string;
  address?: string;
  phonenumber?: string;
  email?: string;
  password?: string;
  desc?:string;
  ceo?:string;
  revenue?:string;
  size?:string;
  industry?:string;
  foundation?:string;
  head?:string;
  locations?:string[];
}