export interface applyjob {


  id?:string;
  idOfJob:string;
  emailofcompany:string;
  email: string;
  fname: string;
  lname: string;
  city: string;
  address: string;
  date: string;
  cvUrl: string;

}
