export interface User_account {
  fname?: string;
  lname?: string;
  email?: string;
  password?: string;
  job_title?:string;
  decription_of_job?:string;
  salary?:number;
  address?:string;
  jobs_completed?:string;
  skills?:string[];

  // Add more properties as needed
}
