import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './components/user/user.component';
import { CompanyComponent } from './components/company/company.component';
import { LoginPageComponent } from './components/login-page/login-page.component';
import { UserRegisterationComponent } from './components/user-registeration/user-registeration.component';
import { CompanyRegisterationComponent } from './components/company-registeration/company-registeration.component';
import { HomeComponent } from './home/home.component';
import { AddJobComponent } from './add-job/add-job.component';
import { CandidatesComponent } from './candidates/candidates.component';
import { JobApplyComponent } from './job-apply/job-apply.component';
import { SavedJobsComponent } from './saved-jobs/saved-jobs.component';
const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' }, // Default route
  {path:'add-job',component:AddJobComponent},
  {path:'candidates',component:CandidatesComponent},
  { path: 'home', component: HomeComponent },
  { path: 'user-profile', component: UserComponent },
  {path:'company-profile', component: CompanyComponent},
  {path:'login',component:LoginPageComponent},
  {path:'user-registeration',component:UserRegisterationComponent},
  {path:'company-registeration',component:CompanyRegisterationComponent},
  {path:'job-apply',component:JobApplyComponent},
  {path:'saved-jobs',component:SavedJobsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
