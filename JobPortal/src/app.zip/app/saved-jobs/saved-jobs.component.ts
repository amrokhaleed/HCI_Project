import { Component, inject } from '@angular/core';
import { JobsDataService } from '../services/jobs-data.service';
@Component({
  selector: 'app-saved-jobs',
  templateUrl: './saved-jobs.component.html',
  styleUrl: './saved-jobs.component.css'
})
export class SavedJobsComponent {
  savedJobs: any = []; // Initialize savedJobs as an empty array of Job type

  constructor(private jobData: JobsDataService) { }

  ngOnInit() {
    this.jobData.getAlljobs().subscribe((jobs: any[]) => {
      // Filter jobs where isSaved is true
      this.savedJobs = jobs.filter(job => job.isSaved === true);
    });

  }
}
