import { Component } from '@angular/core';

@Component({
  selector: 'app-card-holder',
  templateUrl: './card-holder.component.html',
  styleUrl: './card-holder.component.css'
})
export class CardHolderComponent {

}
