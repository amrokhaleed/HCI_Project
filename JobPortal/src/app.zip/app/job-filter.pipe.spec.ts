import { JobFilterPipe } from './job-filter.pipe';

describe('JobFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new JobFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
